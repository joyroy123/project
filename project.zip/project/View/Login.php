<?php
session_start();
$un = $pass="";
$unErr = $passErr ="";
$msg = "";
$error=1;
  
include '../Controller/DataController.php' ;

$data = loadData();
if(isset($_POST["submit"])) {
    
if (empty($_POST["un"])) {
    $unErr = "Username is required";
  } else {
    $un = $_POST["un"];
    $error = 0;
    
    }
  
   
  if (empty($_POST["pass"])) {
    $passErr = "password is required";
    $error = 1;
  } else {
    $pass = $_POST["pass"];
    $error = 0;
    
    }
    if ($error==0){
        foreach($data as $row)  
{  
    
    
    if($row['username']==$_POST["un"] and $row['password']==$_POST["pass"]){
        $_SESSION['name'] = $row['name'];
        $_SESSION['email'] = $row['e-mail'];
        $_SESSION['phone'] = $row['phone'];
        $_SESSION['uname'] = $row['username'];
        $_SESSION['pass'] = $row['password'];
        $_SESSION['class'] = $row['class'];
        $_SESSION['group'] = $row['group'];
        $_SESSION['about'] = $row['about'];
        $_SESSION['dob'] = $row['dob'];
        $_SESSION['gender'] = $row['gender'];
        $_SESSION['area'] = $row['area'];
	    header("location:Profile.php");
        break;
    }
    else{
        $msg = "invalid username or password";
    }
     
}  echo $msg;
    }
  }


 
 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <style>
    .error {color: #FF0000;}
    </style>
    <title>Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
</head>
<body style="background-color: lightblue;">
<form method="post" name="myform" onsubmit="return validate()">  
  <fieldset>
  <h2 align="center" style="color:orangered;">Login Form</h2>
  <table align="center">
  <tr>
    <td><b>Username:</b> </td>
    <td><input type="text" name="un" value="<?php echo $un;?>"></td><br>
    <td><span class="error">* <?php echo $unErr;?></span></td>
  </tr>
  <tr>
    <td><b>Password:</b> </td>
    <td><input type="password" name="pass" ></td>
    <td><span class="error">* <?php echo $passErr;?></span></td>
  </tr>
  </tr>
  <tr><td><input type="submit" name="submit" value="Login" style="background-color:tomato;"></td></tr>
</table>
 


</fieldset>
<script>
    function validate() {
        var un= document.forms["myform"]["un"].value;
        var pass= document.forms["myform"]["pass"].value;

        var subject=document.getElementById("subject");

    if(un==""){
      alert("please enter your username");
      return false; 
    }
    if(!isNaN(un)){
      alert("please enter character");
      return false; 
    }

    if(pass==""){
      alert("please enter your password");
      return false; 
    }
    if(strlen(pass)<8){
      alert("please enter correct password");
      return false; 
    }
    }
</script>
</body>
</html>